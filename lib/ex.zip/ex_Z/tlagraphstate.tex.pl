spec_trans(root,'$initialise_machine',0).
spec_trans(0,'AddEdge(NODE1,NODE1)',1).
spec_trans(0,'AddEdge(NODE1,NODE2)',2).
spec_trans(0,'AddEdge(NODE2,NODE1)',2).
spec_trans(0,'AddEdge(NODE2,NODE2)',3).
spec_trans(1,'AddEdge(NODE1,NODE2)',4).
spec_trans(1,'AddEdge(NODE2,NODE1)',4).
spec_trans(1,'AddEdge(NODE2,NODE2)',5).
spec_not_all_transitions_added(3).
spec_not_all_transitions_added(2).
spec_not_all_transitions_added(4).
spec_not_all_transitions_added(5).
spec_max_reached_for_node(_) :-
        fail.
spec_completely_explored :-
        fail.
