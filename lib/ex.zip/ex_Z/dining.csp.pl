:- dynamic parserVersionNum/1, parserVersionStr/1, parseResult/5.
'parserVersionNum'(1.45e-2).
'parserVersionStr'('\n\n\nThe java-interface is not functional !!! \n\n\nVersion :Version {versionBranch = [0,1,4,5], versionTags = []}\nCompiled at Tue Mar  9 18:57:44 Westeurop\228ische Normalzeit 2010\n(mingw32 i386 ghc 6.10)\nCSPM-Frontend :\nCSPM-Fronted Version {versionBranch = [0,2,10,2], versionTags = []} \nCompiled at Tue Mar  9 18:56:39 Westeurop\228ische Normalzeit 2010 \n( mingw32 i386 ghc 6.10 )').
'parseResult'('ok','',0,0,0).
:- dynamic channel/2, bindval/3, agent/3.
:- dynamic agent_curry/3, symbol/4.
:- dynamic dataTypeDef/2, subTypeDef/2, nameType/2.
:- dynamic cspTransparent/1.
:- dynamic cspPrint/1.
'dataTypeDef'('BPhils',['constructor'('p1'),'constructor'('p2'),'constructor'('p3')]).
'dataTypeDef'('BForks',['constructor'('f1'),'constructor'('f2'),'constructor'('f3')]).
'channel'('think','type'('dotTupleType'(['BPhils']))).
'channel'('eat','type'('dotTupleType'(['BPhils']))).
'channel'('TakeLeftFork','type'('dotTupleType'(['BForks','BPhils']))).
'channel'('TakeRightFork','type'('dotTupleType'(['BForks','BPhils']))).
'channel'('DropFork','type'('dotTupleType'(['BForks','BPhils']))).
'bindval'('MAIN','repInterleave'(['comprehensionGenerator'(_p,'BPhils')],'agent_call'('src_span'(9,23,9,27,178,4),'PHIL',[_p]),'src_span'(9,12,9,22,167,10)),'src_span'(9,1,9,30,156,29)).
'agent'('PHIL'(_P),'prefix'('src_span'(11,11,11,16,197,5),['out'(_P)],'think','prefix'('src_span'(11,22,11,34,208,12),['in'(_fi1),'out'(_P)],'TakeLeftFork','prefix'('src_span'(11,44,11,57,230,13),['in'(_fi2),'out'(_P)],'TakeRightFork','prefix'('src_span'(12,11,12,14,263,3),['out'(_P)],'eat','prefix'('src_span'(12,20,12,28,272,8),['in'(_fi3),'out'(_P)],'DropFork','prefix'('src_span'(12,38,12,46,290,8),['in'(_fi4),'out'(_P)],'DropFork','agent_call'('src_span'(12,56,12,60,308,4),'PHIL',[_P]),'src_span'(12,53,12,55,304,13)),'src_span'(12,35,12,37,286,31)),'src_span'(12,17,12,19,268,49)),'src_span'(11,64,12,10,249,68)),'src_span'(11,41,11,43,226,91)),'src_span'(11,19,11,21,204,113)),'src_span'(11,1,11,5,187,4)).
'symbol'('BPhils','BPhils','src_span'(2,10,2,16,10,6),'Datatype').
'symbol'('p1','p1','src_span'(2,19,2,21,19,2),'Constructor of Datatype someConstructor').
'symbol'('p2','p2','src_span'(2,24,2,26,24,2),'Constructor of Datatype someConstructor').
'symbol'('p3','p3','src_span'(2,29,2,31,29,2),'Constructor of Datatype someConstructor').
'symbol'('BForks','BForks','src_span'(3,10,3,16,41,6),'Datatype').
'symbol'('f1','f1','src_span'(3,19,3,21,50,2),'Constructor of Datatype someConstructor').
'symbol'('f2','f2','src_span'(3,24,3,26,55,2),'Constructor of Datatype someConstructor').
'symbol'('f3','f3','src_span'(3,29,3,31,60,2),'Constructor of Datatype someConstructor').
'symbol'('think','think','src_span'(5,9,5,14,72,5),'Channel').
'symbol'('eat','eat','src_span'(5,16,5,19,79,3),'Channel').
'symbol'('TakeLeftFork','TakeLeftFork','src_span'(6,9,6,21,100,12),'Channel').
'symbol'('TakeRightFork','TakeRightFork','src_span'(6,23,6,36,114,13),'Channel').
'symbol'('DropFork','DropFork','src_span'(6,38,6,46,129,8),'Channel').
'symbol'('MAIN','MAIN','src_span'(9,1,9,5,156,4),'Ident (Groundrep.)').
'symbol'('p','p','src_span'(9,12,9,13,167,1),'Ident (Prolog Variable)').
'symbol'('PHIL','PHIL','src_span'(11,1,11,5,187,4),'Funktion or Process ( Arity :-1)').
'symbol'('P','P','src_span'(11,6,11,7,192,1),'Ident (Prolog Variable)').
'symbol'('fi1','fi1','src_span'(11,35,11,38,221,3),'Ident (Prolog Variable)').
'symbol'('fi2','fi2','src_span'(11,58,11,61,244,3),'Ident (Prolog Variable)').
'symbol'('fi3','fi3','src_span'(12,29,12,32,281,3),'Ident (Prolog Variable)').
'symbol'('fi4','fi4','src_span'(12,47,12,50,299,3),'Ident (Prolog Variable)').